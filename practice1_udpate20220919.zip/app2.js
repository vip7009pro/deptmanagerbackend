const  fs = require('fs').promises;
fs.rm('uploadfiles/CMS WEB ERP.pdf');